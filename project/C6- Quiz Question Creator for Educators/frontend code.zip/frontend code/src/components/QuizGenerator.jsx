import React, { useState } from 'react';
import './QuizGenerator.css'; 
import axios from 'axios';
import QuizDisplay from './QuizDisplay'; // <-- IMPORT THE NEW COMPONENT

const QuizGenerator = () => {
  const [pdfFile, setPdfFile] = useState(null);
  const [numMcq, setNumMcq] = useState(5);
  const [numTrueFalse, setNumTrueFalse] = useState(3);
  const [isLoading, setIsLoading] = useState(false);
  const [quizData, setQuizData] = useState(null);
  const [error, setError] = useState('');

  const handleGenerateQuiz = async () => {
    if (!pdfFile) {
      setError('Please upload a PDF file first.');
      return;
    }
    const formData = new FormData();
    formData.append('file', pdfFile);
    formData.append('num_mcq', numMcq);
    formData.append('num_true_false', numTrueFalse);
    setIsLoading(true);
    setError('');
    setQuizData(null);
    try {
      const response = await axios.post('https://quiz-generator-backend-e1ud.onrender.com/api/generate', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      // The data from the backend might be a string, so we parse it
      setQuizData(response.data);
    } catch (err) {
      console.error('Error generating quiz:', err);
      setError('Failed to generate quiz. The AI model may have returned an unexpected format.');
    } finally {
      setIsLoading(false);
    }
  };

  // --- THE ONLY CHANGE IS HERE ---
  return (
    <div className="quiz-generator-container">
      {!quizData ? (
        <>
          <div className="header">
            <h1>AI Quiz Generator</h1>
            <p>Create a quiz from any PDF document instantly.</p>
            <h2 style={{ color: '#00aaff' }}>Project by Group 40</h2>
          </div>
          <div className="form-card">
            <h2>Step 1: Configure Your Quiz</h2>
            <div className="form-group">
              <label htmlFor="file-upload">Upload PDF Document</label>
              <input type="file" id="file-upload" accept=".pdf" onChange={(e) => setPdfFile(e.target.files[0])} />
            </div>
            <div className="form-group">
              <label htmlFor="num-mcq">Number of Multiple-Choice Questions</label>
              <input type="number" id="num-mcq" value={numMcq} onChange={(e) => setNumMcq(e.target.value)} min="1" />
            </div>
            <div className="form-group">
              <label htmlFor="num-tf">Number of True/False Questions</label>
              <input type="number" id="num-tf" value={numTrueFalse} onChange={(e) => setNumTrueFalse(e.target.value)} min="0" />
            </div>
            {error && <p className="error-message">{error}</p>}
            <button className="generate-button" onClick={handleGenerateQuiz} disabled={!pdfFile || isLoading}>
              {isLoading ? 'Generating...' : 'Generate Quiz'}
            </button>
          </div>
        </>
      ) : (
        // Use our new component to display the quiz beautifully!
        <QuizDisplay quizData={quizData} onStartOver={() => setQuizData(null)} />
      )}
    </div>
  );
};

export default QuizGenerator;