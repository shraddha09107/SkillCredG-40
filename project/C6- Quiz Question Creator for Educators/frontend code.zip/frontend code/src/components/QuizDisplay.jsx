import React, { useState } from 'react';
import './QuizDisplay.css';
import jsPDF from 'jspdf'; // Library to generate PDFs

const QuizDisplay = ({ quizData, onStartOver }) => {
  const [showAnswers, setShowAnswers] = useState(false);

  const handleDownloadPdf = () => {
    const doc = new jsPDF();
    let yPos = 15; // Vertical position in PDF

    doc.setFontSize(18);
    doc.text("Generated Quiz", 105, yPos, { align: 'center' });
    yPos += 15;

    // Add MCQs to PDF
    doc.setFontSize(14);
    doc.text("Multiple-Choice Questions", 15, yPos);
    yPos += 10;
    doc.setFontSize(12);

    quizData.mcqs.forEach((mcq, index) => {
      doc.text(`${index + 1}. ${mcq.question}`, 15, yPos);
      yPos += 7;
      mcq.options.forEach((option, i) => {
        doc.text(`   - ${option}`, 20, yPos);
        yPos += 7;
      });
      doc.text(`   Correct Answer: ${mcq.correct_answer}`, 20, yPos);
      yPos += 12;
    });

    // Add True/False questions to PDF
    yPos += 5;
    doc.setFontSize(14);
    doc.text("True/False Questions", 15, yPos);
    yPos += 10;
    doc.setFontSize(12);

    quizData.true_false.forEach((tf, index) => {
      doc.text(`${index + 1}. ${tf.question}`, 15, yPos);
      yPos += 7;
      doc.text(`   Correct Answer: ${tf.correct_answer}`, 20, yPos);
      yPos += 12;
    });

    doc.save("quiz.pdf");
  };

  return (
    <div className="quiz-display-container">
      <div className="quiz-header">
        <h1>Your Quiz is Ready!</h1>
      </div>

      <div className="action-buttons">
        <button onClick={() => setShowAnswers(!showAnswers)}>
          {showAnswers ? 'Hide Answers' : 'Show Answers'}
        </button>
        <button onClick={handleDownloadPdf}>Download Quiz (PDF)</button>
        <button className="secondary" onClick={onStartOver}>Create New Quiz</button>
      </div>

      {/* Display MCQs */}
      <h2>Multiple-Choice Questions</h2>
      {quizData.mcqs.map((mcq, index) => (
        <div key={index} className="question-card">
          <h3>{index + 1}. {mcq.question}</h3>
          <ul className="options-list">
            {mcq.options.map((option, i) => (
              <li 
                key={i} 
                className={`option ${showAnswers && option === mcq.correct_answer ? 'correct' : ''}`}
              >
                {option}
              </li>
            ))}
          </ul>
        </div>
      ))}

      {/* Display True/False */}
      <h2>True/False Questions</h2>
      {quizData.true_false.map((tf, index) => (
        <div key={index} className="question-card">
          <h3>{index + 1}. {tf.question}</h3>
          {showAnswers && (
            <p className="option correct">
              Answer: {String(tf.correct_answer)}
            </p>
          )}
        </div>
      ))}
    </div>
  );
};

export default QuizDisplay;