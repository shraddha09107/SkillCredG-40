import QuizGenerator from './components/QuizGenerator';

function App() {
  return (
    <div>
      <QuizGenerator />
    </div>
  );
}

export default App;